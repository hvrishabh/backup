(function($, Drupal){
    $(document).ready(function(){
        alert("hello basic page");
    });
})(jquery,Drupal)