<?php

namespace Drupal\ajaxform\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\OpenModalDialogCommand;

/**
 * Class Displayone.
 *
 * @package Drupal\ajaxform\Controller
 */
class Displayone extends ControllerBase
{

    // /**
    //  * {@inheritdoc}
    //  */
    // public function manageContact()
    // {
    // $form['form'] = $this->formBuilder()->getForm('Drupal\ajaxform\Form\addform');
    // $render_array = $this->formBuilder()->getForm('Drupal\ajaxform\Controller\Displayform', 'All');
    // $form['form1'] = $render_array;
    // // $form['form']['#suffix'] = '<div class="pagination">'.getPager().'</div>';

    // // you can write your own query to fetch the data I have given my example.
    // return $render_array;

// }
}
