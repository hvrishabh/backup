// (function($, Drupal, drupalSettings){
//     'use strict';
//     $(document).ready(function(){
//         alert('hello');
//     })

// })(jQuery, Drupal , drupalSettings)