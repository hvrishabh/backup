<?php

namespace Drupal\test\Controller;

use Drupal\Core\Controller\ControllerBase;

class testController extends ControllerBase{

}