<?php

unlink("delete_test.php");

?>