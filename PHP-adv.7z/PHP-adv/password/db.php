<?php
session_start();
$connection = mysqli_connect("localhost", "root", "", "user");

?>