<?php

class house{

}