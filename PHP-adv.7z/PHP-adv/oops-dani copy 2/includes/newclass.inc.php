<?php

class NewClass{
    // properties and methods goes here
    public $info = "This is some info";
}

// instances a class , i.e creating an objext

$object = new NewClass;
print_r($object);
echo "<br>";
// echo $object->info;
// var_dump($object);