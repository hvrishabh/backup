<?php
echo "<pre>";
echo "hello cURL";

// print_r($_GET);

print_r($_POST);

// $array = [
//     'one' => 1,
//     'two' => 2
// ];

// print_r($array);