<?php

//Exception handling in php oops

// try{
//     // some multiple lines of code
// }catch(){
//     // when any error comes in try code
//     // it comes with a lots of function to read the errors.
// }


// --------------------------------------------------


// try{
//     if(condition){

//     }else{
//         throw new Exception("some Message GOes HERE");
//     }
// }catch(Exception $e){
//     echo $e->getMessage();
//     // some inbulit messages
//     // $e->getLine();   // it will show which line is throwing error
//     // $e->getCode();   // it will show , code khase start hua hai
//     // $e->getFile();   // konsi file se error aa rha hai. if using multiple files
// }

