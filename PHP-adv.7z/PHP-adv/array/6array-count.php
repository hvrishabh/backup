<?php
$a=array("A","Cat","Dog","A","Dog");
$c = (array_count_values($a));

echo "<pre>";
print_r($c);
echo "</pre>";
?>
