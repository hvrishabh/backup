<?php
$fname=array("Peter","Ben","Joe");
$age=array("35","37","43");

$c=array_combine($age,$fname);
print_r($c);


echo "<pre>";
print_r($c);
echo "</pre>";
?>