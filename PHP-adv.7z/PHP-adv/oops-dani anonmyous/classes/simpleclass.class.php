<?php
class SimpleClass{
    public function helloWorld(){
        echo "Hello World!";
    }
}